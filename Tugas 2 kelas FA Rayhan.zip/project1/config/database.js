const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('mahasiswa', 'root', 'bor1211', {
    host: 'localhost',
    dialect: 'mysql'
});

module.exports = sequelize;
