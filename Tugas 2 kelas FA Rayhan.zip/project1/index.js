const express = require('express');
const sequelize = require('./config/database');
const User = require('./models/users');

const app = express();
const port = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Test koneksi database
sequelize.authenticate()
    .then(() => console.log('Terhubung ke MySQL'))
    .catch(err => console.error('Gagal koneksi:', err));

// Sinkronisasi model
sequelize.sync();

// Login endpoint
app.post('/login', async (req, res) => {
    const { nim, password } = req.body;

    try {
        const user = await User.findOne({ where: { nim, password } });

        if (user) {
            res.send('Login berhasil!');
        } else {
            res.status(401).send('NIM atau Password salah');
        }
    } catch (error) {
        console.error(error);
        res.status(500).send('Terjadi kesalahan server');
    }
});


app.post('/register', async (req, res) => {
    const { nim, password } = req.body;

    try {
        await User.create({ nim, password });
        res.send('Registrasi berhasil!');
    } catch (error) {
        console.error(error);
        res.status(500).send('Terjadi kesalahan server');
    }
});

app.listen(port, () => console.log(`Server berjalan di http://localhost:${port}`));
