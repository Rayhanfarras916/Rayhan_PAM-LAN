package com.example.userapp

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class UserViewModel : ViewModel() {
    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users

    private val _userDetail = MutableStateFlow<User?>(null)
    val userDetail: StateFlow<User?> = _userDetail

    init {
        viewModelScope.launch {
            _users.value = ApiClient.apiService.getUsers()
        }
    }

    fun fetchUserDetail(id: Int) {
        viewModelScope.launch {
            _userDetail.value = ApiClient.apiService.getUserById(id)
        }
    }
}
