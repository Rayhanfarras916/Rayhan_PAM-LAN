package com.example.userapp

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun UserListScreen(navController: NavController, viewModel: UserViewModel) {
    val users by viewModel.users.collectAsState()

    Column {
        Text("Rayhan Farras Ramadhan - 205150407111020", fontSize = 20.sp, modifier = Modifier.padding(8.dp))
        LazyColumn {
            items(users) { user ->
                Card(modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
                    .clickable { navController.navigate("userDetail/${user.id}") }) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(user.name, fontSize = 18.sp)
                        Text(user.email)
                    }
                }
            }
        }
    }
}
