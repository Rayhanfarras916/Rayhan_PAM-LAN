package com.example.userapp

import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun UserDetailScreen(viewModel: UserViewModel) {
    val user by viewModel.userDetail.collectAsState()

    user?.let {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Name: ${it.name}", fontSize = 20.sp)
            Text("Username: ${it.username}")
            Text("Email: ${it.email}")
        }
    } ?: run {
        Text("Loading...", modifier = Modifier.padding(16.dp))
    }
}
